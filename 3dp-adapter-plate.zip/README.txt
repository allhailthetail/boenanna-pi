Raspberry Pi to BOE-BOT Adapter Plate by tjredhawke on Thingiverse: https://www.thingiverse.com/thing:1562194

Summary:
A colleague asked me to design an adapter plate so that he could mount a Raspberry Pi to his BOE-BOT.  Here is the result (with fins).